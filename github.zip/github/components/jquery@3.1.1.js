define(["github:components/jquery@3.1.1/jquery.js"], function(main) {
  return main;
});