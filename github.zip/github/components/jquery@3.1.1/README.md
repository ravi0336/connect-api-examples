jQuery Component
================

Shim [repository](https://github.com/components/jquery) for the [jQuery](http://jquery.com).

If you're looking for jquery-migrate: It got it's [own repository](https://github.com/components/jquery-migrate) since jQuery v3.0.0.

Package Managers
----------------

* [Bower](http://bower.io/): `jquery`
* [Component](https://github.com/component/component): `components/jquery`
* [Composer](http://packagist.org/packages/components/jquery): `components/jquery`
* [spm](http://spmjs.io/package/jquery): `jquery`
