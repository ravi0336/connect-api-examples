System.register(["github:frankwallis/plugin-typescript@5.2.7/plugin"], function($__export) {
  return {  setters: [function(m) { for (var p in m) $__export(p, m[p]); }],  execute: function() {}  };
});