/* */ 
require('../modules/es7.map.to-json');
module.exports = require('../modules/_core').Map;
