/* */ 
module.exports = { "default": require("core-js/library/fn/array/for-each"), __esModule: true };