/* */ 
module.exports = { "default": require("core-js/library/fn/array/push"), __esModule: true };