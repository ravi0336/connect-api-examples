/* */ 
module.exports = { "default": require("core-js/library/fn/array/unshift"), __esModule: true };