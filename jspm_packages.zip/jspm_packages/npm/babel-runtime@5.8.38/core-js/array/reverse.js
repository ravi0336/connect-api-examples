/* */ 
module.exports = { "default": require("core-js/library/fn/array/reverse"), __esModule: true };