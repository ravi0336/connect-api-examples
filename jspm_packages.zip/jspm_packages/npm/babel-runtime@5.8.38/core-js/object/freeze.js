/* */ 
module.exports = { "default": require("core-js/library/fn/object/freeze"), __esModule: true };