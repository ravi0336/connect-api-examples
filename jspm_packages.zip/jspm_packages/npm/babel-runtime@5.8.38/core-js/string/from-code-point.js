/* */ 
module.exports = { "default": require("core-js/library/fn/string/from-code-point"), __esModule: true };