/* */ 
module.exports = { "default": require("core-js/library/fn/string/starts-with"), __esModule: true };