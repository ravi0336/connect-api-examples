/* */ 
module.exports = { "default": require("core-js/library/fn/math/atanh"), __esModule: true };