/* */ 
module.exports = { "default": require("core-js/library/fn/math/pot"), __esModule: true };