/* */ 
module.exports = { "default": require("core-js/library/fn/set"), __esModule: true };